import os,sys,json,time,threading,statistics,hashlib
from pathlib import Path
repo=Path('C:/Users/tanzir/Desktop/voice_tray');sys.path.insert(0,str(repo))
qa=Path(__file__).resolve().parent
from tools.public_file_guard import install
install(qa/'cpu-passive.guard.json')
from saydraft.cleanup.llm.sidecar import SidecarConfig,SidecarManager
from saydraft.cleanup.llm.candidates import get_candidate,candidate_directory,candidate_weight
from saydraft.privacy.netguard import NetworkGuard
from tools.bench_cleanup import NativeMeter,throughput
cache=qa.parent/'cleanup-candidates'
runtime=qa.parent/'llama-runtime-install-b12110/llama-cpp-b12110-cpu-x64'
candidate=get_candidate('qwen35-08b-q4-k-m')
model=candidate_weight(candidate,candidate_directory(cache,candidate))
report={'scope':'cache-only CPU thread diagnostic; no ASR or native desktop access','model_sha256':hashlib.file_digest(model.open('rb'),'sha256').hexdigest(),'rows':[]}
NetworkGuard.install()
try:
 for threads,poll,passive in [(4,None,False),(4,None,True),(4,0,True),(6,0,True),(1,None,True),(4,None,False)]:
  meter=NativeMeter()
  def spawn(argv,**kwargs):
   if poll is not None:argv=[*argv,'--poll',str(poll),'--poll-batch',str(poll)]
   if passive:kwargs['env']={**kwargs['env'],'OMP_WAIT_POLICY':'PASSIVE','KMP_BLOCKTIME':'0'}
   return meter.spawn(argv,**kwargs)
  manager=SidecarManager(SidecarConfig(model,backend='cpu',threads=threads,startup_seconds=60,max_restarts=0),resolver=lambda _:runtime,process_factory=spawn)
  watchdog=threading.Timer(150,manager.close);watchdog.daemon=True;watchdog.start()
  row={'threads':threads,'poll':poll,'passive':passive}
  try:
   start=time.perf_counter();row['prepared']=manager.prepare();row['prepare_seconds']=time.perf_counter()-start
   if not row['prepared']:raise RuntimeError('Model preparation failed')
   row['samples']=throughput(manager,3,60)
   if not all(s['valid'] for s in row['samples']):raise RuntimeError('Incomplete decoder samples')
   row['median_tps']=statistics.median(s['tokens_per_second'] for s in row['samples'])
  finally:
   manager.close();watchdog.cancel();row['native_exit_observed']=meter.finish()
  report['rows'].append(row)
  (qa/'cpu-passive.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
  print(json.dumps({k:row[k] for k in ['threads','poll','passive','median_tps','native_exit_observed']}),flush=True)
finally:NetworkGuard.uninstall()
