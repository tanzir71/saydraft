"""Independently verify completed 44ed latency matrices; stdlib, no app imports."""
import argparse,hashlib,importlib.metadata as metadata,io,json,math,platform,sqlite3,struct,subprocess,sys,wave
from collections import Counter
from pathlib import Path,PurePosixPath

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run',type=Path,required=True)
parser.add_argument('--repo',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--original-inputs',action='store_true')
parser.add_argument('--input-root',type=Path)
parser.add_argument('--snapshot',type=Path)
args=parser.parse_args()
source='44ed9c458a78e84e55751b827ed71b96114632ae'
root=args.run.resolve()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def member(base,name):
 relative=PurePosixPath(name)
 assert relative.as_posix()==name and not relative.is_absolute() and '..' not in relative.parts and '\\' not in name and ':' not in name
 path=base.joinpath(*relative.parts)
 assert not path.is_symlink() and path.resolve().is_relative_to(base.resolve())
 return path
def git(name):return subprocess.check_output(['git','show',source+':'+name],cwd=args.repo)
def guard(path,gpu):
 base=read(path);fixture=read(path.with_suffix('.worker.json'))
 assert type(base['pid']) is int and base['pid']>0 and base['pid']==fixture['pid']
 assert base['blocked_attempts']==fixture['port_attempts']==[]
 assert fixture['kind']=='public-file-worker-with-refusing-foreground-port'
 assert fixture['production_context_adapter_loaded'] is False and fixture['selection_value_fields']==['target','selection']
 assert all(base[k] is False for k in ['real_audio_sdk_imported','owner_profile_used','owner_clipboard_used','owner_native_input_used','device_enumeration','microphone_used'])
 assert base.get('gpu_metadata_allowed',False) is gpu
 assert isinstance(base.get('gpu_metadata_dlls',[]),list)
 for row in base.get('gpu_metadata_dlls',[]):
  assert gpu and row=={'caller':'saydraft.models.windows_hardware','dll':'vulkan-1.dll','system32_only':True}
 return base['pid']
r=read(root/'report.json')
terminal=read(root/'observed-parent-exit.json')
assert terminal['exit_code']==0 and terminal['parent_exit_observed'] is True and terminal['source']==source
assert terminal['debug_fixture'] is False and terminal['report_sha256']==digest(root/'report.json')
assert r['git_commit']==source and r['complete'] and r['full_matrix']
assert not r['debug'] and not r['source_dirty'] and r['isolation_declared']
assert r['source_unchanged'] and r['runtime_environment_unchanged'] and r['file_only_guards_verified']
assert r['durations']==[3,10,30,90] and r['repeats_per_cell']==20 and len(r['pairs'])==80 and len(r['cases'])==160
tier=r['tier_recipe'];assert tier in ['standard','pro']
gpu=tier=='pro';candidate='qwen35-2b-q4-k-m' if gpu else 'qwen35-08b-q4-k-m'
assert r['candidate']==candidate and r['asr_model']=='parakeet-tdt-0-6b-v3-int8'
assert r['backend']==('vulkan' if gpu else 'cpu') and r['decode_target_tps']==(40 if gpu else 25)
assert r['device']==('Vulkan1' if gpu else None) and r['allow_gpu_metadata'] is gpu
parent_guard=root/'parent.guard.json' if (root/'parent.guard.json').exists() else root.with_suffix('.guard.json')
guard(parent_guard,gpu)
fixture=git('assets/audio/benchmark.wav')
with wave.open(io.BytesIO(fixture),'rb') as audio:
 assert (audio.getnchannels(),audio.getframerate(),audio.getsampwidth(),audio.getnframes())==(1,16000,2,128000)
 frames=audio.readframes(128000)
samples=b''.join(struct.pack('<f',value[0]/32768) for value in struct.iter_unpack('<h',frames))
audio_hashes={seconds:hashlib.sha256((samples*math.ceil(seconds/8))[:seconds*16000*4]).hexdigest() for seconds in [3,10,30,90]}
combined=[];pids=set();identities=set();native=0;files={};requests=[];db_checks=0
for entry in r['pairs']:
 path=member(root,entry['path']);assert digest(path)==entry['sha256']
 child=read(path);request=read(path.with_name('request.json'));requests.append(request)
 assert child['complete'] and child['git_commit']==source and child['runtime_environment']==r['runtime_environment']
 identity=(child['audio_seconds'],child['repeat'])
 assert identity not in identities and identity[0] in [3,10,30,90] and type(identity[1]) is int and 0<=identity[1]<20
 identities.add(identity)
 for name in ['git_commit','runtime_environment','asr_model','candidate','backend','device','decode_target_tps','allow_gpu_metadata']:
  assert request[name]==r[name]
 assert request['tier']==tier and request['audio_seconds']==identity[0] and request['repeat']==identity[1]
 assert child['source_fixture_sha256']==hashlib.sha256(fixture).hexdigest() and child['replay_samples_sha256']==audio_hashes[identity[0]]
 assert child['native_exits'] and all(value is True for value in child['native_exits'])
 assert entry['native_processes']==len(child['native_exits']) and entry['native_exits']==child['native_exits']
 native+=len(child['native_exits'])
 pid=guard(path.with_name('owner-io-guard.json'),gpu)
 assert child['python_pid']==pid and pid not in pids;pids.add(pid)
 process=read(path.with_name('process.json'));assert process['exit_code']==0 and not process['uncaught_error_types']
 for kind,name in [('guard','owner-io-guard.json'),('fixture','owner-io-guard.worker.json')]:
  assert entry['file_only_guard']['verified'] is True and digest(path.with_name(name))==entry['file_only_guard'][kind]['sha256']
 assert entry['file_only_guard']['actual_python_pid']==pid and entry['file_only_guard']['gpu_metadata_allowed'] is gpu
 journal=[json.loads(line) for line in path.with_name('cases.jsonl').read_text(encoding='utf-8').splitlines()]
 assert journal==child['cases'] and [row['phase'] for row in journal]==['cold','warm']
 for row in journal:
  assert (row['audio_seconds'],row['repeat'])==identity and row['fed_samples']==identity[0]*16000 and row['asr_model']==r['asr_model']
  assert all(row[k] is True for k in ['history_before_paste','clipboard_restored','no_early_delivery','release_deadline_present','language_identifier_ready'])
  assert type(row['release_to_paste_seconds']) in (int,float) and math.isfinite(row['release_to_paste_seconds']) and row['release_to_paste_seconds']>=0
 if args.original_inputs:
  database=path.with_name('history.db');assert database.is_file()
  with sqlite3.connect(database.as_uri()+'?mode=ro',uri=True) as connection:
   rows=connection.execute('SELECT id,raw_text,cleaned_text,llm_decision,model,timings_json FROM dictations ORDER BY id').fetchall()
  assert len(rows)==2
  for index,(saved,record) in enumerate(zip(rows,journal,strict=True),1):
   assert saved[0]==index and saved[1] and saved[2] and saved[3]==record['decision'] and saved[4]==record['asr_model']
   assert json.loads(saved[5])==record['timings']
  db_checks+=1
 for name in ['report.json','request.json','process.json','cases.jsonl','owner-io-guard.json','owner-io-guard.worker.json']:
  item=path.with_name(name);files[item.relative_to(root).as_posix()]=digest(item)
 combined.extend(journal)
assert combined==r['cases'] and identities=={(seconds,repeat) for seconds in [3,10,30,90] for repeat in range(20)}
groups={}
for phase in ['cold','warm']:
 for seconds in [3,10,30,90]:
  matching=[row for row in combined if row['phase']==phase and row['audio_seconds']==seconds]
  values=sorted(row['release_to_paste_seconds'] for row in matching);assert len(values)==20
  groups[f'{phase}-{seconds}']=dict(n=20,p50_seconds=values[9],p95_seconds=values[18],max_seconds=values[-1],decisions=dict(Counter(row['decision'] for row in matching)))
accepted={phase:sum(row['decision']=='accepted' for row in combined if row['phase']==phase) for phase in ['cold','warm']}
summary=dict(groups=groups,p50_target_seconds=1.2,p95_target_seconds=2.0,latency_targets_met=all(g['p50_seconds']<=1.2 and g['p95_seconds']<=2 for g in groups.values()),accepted_by_phase=accepted,actual_model_use=all(accepted.values()))
assert summary==r['summary']
decoder=all(row.get('cleanup_at_release',{}).get('decoder',{}).get('median_tps',0)>=r['decode_target_tps'] for row in combined)
latency=summary['latency_targets_met'] and summary['actual_model_use']
assert r['decoder_target_met'] is decoder and r['latency_target_met'] is latency and r['tier_recipe_target_met'] is (latency and decoder)
names=list(r['source_fingerprints'])
batch=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=args.repo,input=('\n'.join(source+':'+name for name in names)+'\n').encode()))
converted=[]
for name in names:
 header=batch.readline().split();assert len(header)==3 and header[1]==b'blob'
 data=batch.read(int(header[2]));assert batch.read(1)==b'\n'
 if hashlib.sha256(data).hexdigest()!=r['source_fingerprints'][name]:
  assert b'\r' not in data and b'\0' not in data and hashlib.sha256(data.replace(b'\n',b'\r\n')).hexdigest()==r['source_fingerprints'][name],name
  converted.append(name)
if converted:
 raw=subprocess.check_output(['git','check-attr','--source='+source,'-z','--stdin','text','eol'],cwd=args.repo,input=('\0'.join(converted)+'\0').encode()).split(b'\0')
 attrs={(raw[i].decode(),raw[i+1]):raw[i+2] for i in range(0,len(raw)-1,3)}
 assert all(attrs[name,b'text'] in [b'auto',b'set'] and attrs[name,b'eol'] in [b'unspecified',b'crlf'] for name in converted)
models={}
if args.original_inputs:
 assert args.input_root and args.snapshot
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=args.snapshot,text=True).strip()==source
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=args.snapshot,text=True).strip()
 for name,value in r['source_fingerprints'].items():assert digest(member(args.snapshot,name))==value,name
 environment={'python':platform.python_version(),'implementation':sys.implementation.name,'cache_tag':sys.implementation.cache_tag,'architecture':platform.machine(),'interpreter_sha256':digest(Path(sys.executable)),
  'packages':{name:metadata.version(name) for name in ['numpy','soundfile','webrtcvad-wheels','faster-whisper','ctranslate2','sherpa-onnx','sherpa-onnx-core','onnxruntime']}}
 assert environment==r['runtime_environment']
 catalog={m['id']:m for m in json.loads(git('saydraft/models/manifest.json'))['models']}
 candidates={m['id']:m for m in json.loads(git('eval/cleanup/candidates.json'))['models']};model=candidates[candidate]
 cache=args.input_root.resolve()
 recipe={'parakeet_dir':('parakeet-tdt-0-6b-v3-int8','parakeet-models/asr/parakeet-tdt-0-6b-v3-int8'),
  'lid_dir':('whisper-tiny-lid-int8','whisper-lid'),'vad_dir':('silero-vad-v5','latency-model-inputs/silero-vad-v5'),
  'runtime_dir':('llama-cpp-b12110-vulkan-x64' if gpu else 'llama-cpp-b12110-cpu-x64',
   'command-session-app-cache-20261114-01/llama-cpp-b12110-vulkan-x64/github-release-asset-709511274' if gpu else 'llama-runtime-install-b12110/llama-cpp-b12110-cpu-x64')}
 for field,(identifier,relative) in recipe.items():
  directory=member(cache,relative);assert all(Path(request[field]).resolve()==directory.resolve() for request in requests)
  record=catalog[identifier];checked={}
  for entry in record['files']:
   path=member(directory,entry['path']);assert path.stat().st_size==entry['size'] and digest(path)==entry['sha256']
   checked[entry['path']]=entry['sha256']
  models[identifier]={'path':str(directory),'files':checked}
 directory=member(cache,'cleanup-candidates/'+candidate+'/'+model['revision'])
 assert all(Path(request['models_dir']).resolve()==cache/'cleanup-candidates' for request in requests)
 checked={}
 for entry in model['files']:
  path=member(directory,entry['path']);assert path.stat().st_size==entry['size'] and digest(path)==entry['sha256'];checked[entry['path']]=entry['sha256']
 notice=model['notice'];path=directory/'LICENSE.txt'
 assert path.stat().st_size==notice['size'] and digest(path)==notice['sha256']==hashlib.sha256(git(notice['path'])).hexdigest()
 checked['LICENSE.txt']=notice['sha256'];models[candidate]={'path':str(directory),'files':checked}
result=dict(source=source,tier=tier,complete=True,full_matrix=True,cases=160,pairs=80,native_exits=native,unique_python_children=len(pids),
 report_sha256=digest(root/'report.json'),source_objects_verified=len(names),windows_text_checkouts=len(converted),metadata_files=files,
 original_inputs_verified=args.original_inputs,qa_history_databases_verified=db_checks,models=models,summary=summary,
 decoder_target_met=decoder,latency_target_met=latency,tier_recipe_target_met=latency and decoder,
 physical_windows_input_measured=False,owner_accuracy_accepted=False,release_ready=False)
with args.output.open('x',encoding='utf-8') as output:json.dump(result,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['metadata_files','models','summary']}))
