from pathlib import Path
from tests.test_hub import subject


def test_notes_recording_row(subject):
    from saydraft.ui.fonts import install_bundled_fonts
    from saydraft.ui.theme import install_theme
    application = subject.qt.QtWidgets.QApplication.instance()
    install_bundled_fonts(application, QtGui=subject.qt.QtGui)
    theme = install_theme(application, mode='dark')
    assert theme is not None
    hub = subject.hub
    hub.resize(1120, 760)
    hub.show_page('Notes')
    hub.show()
    subject.qt.QtWidgets.QApplication.processEvents()
    page = hub.notes_page
    assert page.record_button.isVisible() and page.record_hint.isVisible()
    output = Path(__file__).parent / 'notes-idle-themed.png'
    assert hub.grab().save(str(output))
    page.accept_recording_status('recording')
    subject.qt.QtWidgets.QApplication.processEvents()
    assert hub.grab().save(str(output.with_name('notes-recording-themed.png')))
