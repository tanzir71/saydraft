import sys,subprocess
from pathlib import Path
sys.path.insert(0,'C:/Users/tanzir/Desktop/voice_tray')
from tools.public_file_guard import install
q=Path(__file__).resolve().parent;install(q/'runtime-help.guard.json')
from saydraft.cleanup.llm.sidecar import child_environment
exe=q.parent/'llama-runtime-install-b12110/llama-cpp-b12110-cpu-x64/llama-server.exe'
r=subprocess.run([str(exe),'--help'],env=child_environment('public-diagnostic-placeholder'),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
raw=r.stdout+r.stderr;(q/'runtime-help.txt').write_bytes(raw)
lines=raw.decode('utf-8',errors='replace').splitlines()
for i,line in enumerate(lines):
 if any(term in line for term in ['--threads','--poll','--cpu-mask','--cpu-strict','--prio','--flash-attn']):print('\n'.join(lines[i:i+4]))
raise SystemExit(r.returncode)
