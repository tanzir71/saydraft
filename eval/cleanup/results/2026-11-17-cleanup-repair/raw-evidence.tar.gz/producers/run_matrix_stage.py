import sys
from pathlib import Path
repo=Path('C:/Users/tanzir/Desktop/voice_tray');sys.path.insert(0,str(repo))
q=Path(__file__).resolve().parent;label=sys.argv[1];backend=sys.argv[2]
import traceback,json
def failure(kind,error,tb):
 (q/(label+'.failure.json')).write_text(json.dumps({'type':kind.__name__,'traceback':''.join(traceback.format_exception(kind,error,tb)),'stdout_available':sys.stdout is not None,'stderr_available':sys.stderr is not None},indent=2),encoding='utf-8')
sys.excepthook=failure
from tools.public_file_guard import install
install(q/(label+'.guard.json'),allow_gpu_metadata=backend=='vulkan')
import tools.bench_cleanup as bench
from saydraft.models.hardware import probe_hardware
from saydraft.models.windows_hardware import cpu_features,physical_memory
bench.probe_hardware=lambda:probe_hardware(probes={'cpu_features':cpu_features,'ram_bytes':physical_memory})
args=['--candidate','qwen35-08b-q4-k-m' if backend=='cpu' else 'qwen35-2b-q4-k-m','--models-dir',str(q.parent/'cleanup-candidates'),'--runtime-dir',str(q.parent/f'llama-runtime-install-b12110/llama-cpp-b12110-{backend}-x64'),'--output',str(q/label),'--backend',backend,'--threads','4','--isolated','--include-text']
if backend=='vulkan':args+=['--device','Vulkan1']
if sys.argv[3]=='policy':args+=['--interactive-policy']
raise SystemExit(bench.main(args))
