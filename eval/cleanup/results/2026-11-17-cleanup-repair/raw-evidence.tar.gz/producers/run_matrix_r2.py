import os,sys,time,json,threading,subprocess
from pathlib import Path
repo=Path('C:/Users/tanzir/Desktop/voice_tray');sys.path.insert(0,str(repo))
q=Path(__file__).resolve().parent
from tools.public_file_guard import install
install(q/'matrix-controller-r2.guard.json')
from saydraft.cleanup.llm.windows_process import WindowsJobProcess
python=q.parent/'app-ui-v2-package-20261116-r1/venv/Scripts/python.exe'
source='7e09baef8f6ed3f4fa7367501dd98fdea8820ab6'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
report={'source_commit':source,'stages':[],'complete':False}
(q/'matrix-status-r2.json').write_text(json.dumps(report,indent=2))
for label,backend,mode in [('cpu-forced-r2','cpu','forced'),('pro-forced-r2','vulkan','forced'),('cpu-policy-r2','cpu','policy'),('pro-policy-r2','vulkan','policy')]:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
 row={'label':label,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};report['stages'].append(row)
 (q/'matrix-status-r2.json').write_text(json.dumps(report,indent=2))
 print(json.dumps({'started':label}),flush=True)
 env={k:v for k,v in os.environ.items() if k.upper() in ['SYSTEMROOT','WINDIR','TEMP','TMP']}
 env.update(PATH='C:/Program Files/Git/cmd;C:/Windows/System32;C:/Windows;C:/Python313',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
 started=time.monotonic();process=None
 with (q/(label+'.log')).open('wb') as log:
  def output(data):log.write(data);log.flush()
  try:
   process=WindowsJobProcess([str(python),str(q/'run_matrix_stage.py'),label,backend,mode],env=env,cwd=repo,on_output=output)
   limit=1800;heartbeat=started
   while process.poll_tree() is None:
    now=time.monotonic()
    if now-started>limit:process.terminate();raise TimeoutError('Bounded cleanup stage expired')
    if now-heartbeat>=30:
     print(json.dumps({'running':label,'elapsed_seconds':round(now-started)}),flush=True);heartbeat=now
    time.sleep(.2)
   row['exit_code']=process.wait_tree(10);process.finish_output(10);row['tree_exit_observed']=True
  finally:
   if process is not None:process.close()
 row['seconds']=time.monotonic()-started
 if (q/label/'report.json').is_file():
  result=json.loads((q/label/'report.json').read_text())
  row.update(golden_exact=result['suites']['golden']['exact_passes'],golden_regressions=result['suites']['golden']['regressions'],accepted_golden=result['suites']['golden']['accepted_replies'],preservation_failures=result['suites']['golden']['preservation_failures']+result['suites']['adversarial']['preservation_failures'])
 (q/'matrix-status-r2.json').write_text(json.dumps(report,indent=2))
 print(json.dumps(row),flush=True)
 if row['exit_code']!=0:raise SystemExit(row['exit_code'])
report['complete']=True;(q/'matrix-status-r2.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'matrix_complete':True}),flush=True)
