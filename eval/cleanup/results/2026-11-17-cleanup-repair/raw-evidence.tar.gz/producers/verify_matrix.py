import json,hashlib,subprocess,sys
from pathlib import Path
repo=Path('C:/Users/tanzir/Desktop/voice_tray');q=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
golden=[json.loads(line) for line in (repo/'tests/eval_corpus.jsonl').read_bytes().splitlines() if line.strip()]
adversarial=[json.loads(line) for line in (repo/'tests/cleanup_adversarial.jsonl').read_bytes().splitlines() if line.strip()]
assert len(golden)==556 and len(adversarial)==100
expected={('golden',r['id']):r for r in golden}|{('adversarial',r['id']):r for r in adversarial}
forced_state=json.loads((q/'matrix-status-r2.json').read_bytes())
state=json.loads((q/'matrix-status-r3.json').read_bytes());assert state['complete']
forced_stages=[s for s in forced_state['stages'] if 'forced' in s['label']]
assert len(forced_stages)==2
stages=forced_stages+state['stages']
results=[]
for stage in stages:
 label=stage['label'];report=json.loads((q/label/'report.json').read_bytes())
 rows=[json.loads(line) for line in (q/label/'cases.jsonl').read_bytes().splitlines()]
 assert stage['exit_code']==0 and stage['tree_exit_observed']
 assert report['git_commit']==(forced_state['source_commit'] if 'forced' in label else state['source_commit']) and report['source_dirty'] is False
 assert report['native_exit_observed'] and all(value is True for value in report['native_exit_observed'])
 assert not report.get('error_type')
 assert len(rows)==656 and {(row['suite'],row['id']) for row in rows}==expected.keys()
 exact=accepted=0;failures=[]
 for row in rows:
  case=expected[row['suite'],row['id']]
  assert row['input']==case['input'] and row['input_sha256']==sha(row['input'].encode())
  assert row['output_sha256']==sha(row['actual'].encode()) and row['baseline_sha256']==sha(row['rules'].encode())
  if row['suite']=='golden':
   assert row['expected']==case['expected']
   passed=row['actual']==case['expected'] and row['enter_sent']==case.get('expected_enter',False)
   assert passed==row['exact_pass']
   exact+=passed;accepted+=row['decision']=='accepted'
   if not passed:failures.append(row['id'])
 assert exact==report['suites']['golden']['exact_passes']
 assert accepted==report['suites']['golden']['accepted_replies']
 for suite in ['golden','adversarial']:
  group=[r for r in rows if r['suite']==suite];summary=report['suites'][suite]
  assert summary['completed']==summary['requested']==len(group)
  assert summary['preservation_failures']==[r['id'] for r in group if not r['preservation_ok']]
  assert summary['client_replies_with_token_counts']==sum(call.get('source_tokens',0)>0 for r in group for call in r['calls'])
 guard=json.loads((q/(label+'.guard.json')).read_bytes())
 assert guard['blocked_attempts']==[]
 assert not any(guard[k] for k in ['real_audio_sdk_imported','owner_profile_used','owner_clipboard_used','owner_native_input_used','device_enumeration','microphone_used'])
 results.append({'stage':label,'rows':len(rows),'golden_exact':exact,'accepted_golden':accepted,'mismatches':failures,'native_exit_observed':report['native_exit_observed']})
result={'source_commits':{'forced':forced_state['source_commit'],'policy':state['source_commit']},'passed':True,'stages':results,'scope':'independent original input/output hashes, exact scoring, suite/model-credit counts and owned exits; preservation uses recorded finite guard results'}
(q/'matrix-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
