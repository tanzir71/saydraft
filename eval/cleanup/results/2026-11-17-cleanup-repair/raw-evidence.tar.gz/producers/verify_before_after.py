import sys,json,hashlib,subprocess,types
from pathlib import Path
repo=Path('C:/Users/tanzir/Desktop/voice_tray');sys.path.insert(0,str(repo))
q=Path(__file__).resolve().parent
from tools.public_file_guard import install
install(q/'before-after.guard.json')
for finder in sys.meta_path:
 if type(finder).__name__=='OwnerIOGuard':
  original=finder.find_spec
  finder.find_spec=lambda fullname,path=None,target=None,original=original:None if fullname in ('saydraft.context.foreground','saydraft.context.uia_native','saydraft.insert.clipboard_win') else original(fullname,path,target)
sys.path.append('C:/Users/tanzir/AppData/Roaming/Python/Python313/site-packages')
old_commit='ab984004eebb57b4a3b3cc97aa017290591d5695';fixed_commit='7e09baef8f6ed3f4fa7367501dd98fdea8820ab6'
def old_module(path,name,package):
 raw=subprocess.check_output(['git','show',old_commit+':'+path],cwd=repo)
 module=types.ModuleType(name);module.__package__=package
 exec(compile(raw,str(repo/path),'exec'),module.__dict__)
 return module,hashlib.sha256(raw).hexdigest()
old_structure,structure_sha=old_module('saydraft/cleanup/llm/structure.py','baseline_structure','saydraft.cleanup.llm')
from saydraft.cleanup.llm.structure import rule_structure_reason
cases=[('Hello comma world','Hello, comma, world'),('Hello comma team.','Hello, comma team.'),('Thanks comma talk soon','Thanks, comma talk soon')]
commas=[{'source':a,'candidate':b,'before':old_structure.rule_structure_reason(a,b),'after':rule_structure_reason(a,b)} for a,b in cases]
assert all(row['before'] is None and row['after']=='rules_literal_comma_changed' for row in commas)
old_worker,worker_sha=old_module('saydraft/core/worker.py','baseline_worker','saydraft.core')
from tests import test_session_worker as helper
from tests.test_cpu_cleanup_startup import prepared_worker
original=helper.SessionWorker
orders={}
try:
 for label,kind in [('before',old_worker.SessionWorker),('after',original)]:
  helper.SessionWorker=kind
  worker,executor,order,_=prepared_worker(queued=True)
  try:
   worker.warm_recognition();executor.drain()
   orders[label]={'order':list(order),'microphone_starts':worker.services.recorder.started}
  finally:worker.shutdown()
finally:helper.SessionWorker=original
assert orders['before']['order']==['cleanup','speech'] and orders['after']['order']==['speech','cleanup']
assert all(row['microphone_starts']==0 for row in orders.values())
report={'baseline_commit':old_commit,'fixed_commit':fixed_commit,'baseline_source_sha256':{'structure':structure_sha,'worker':worker_sha},'comma_guards':commas,'startup_order':orders,'passed':True,'scope':'original source replay with fake services; no native owner ports'}
(q/'before-after.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'before_after_passed':True,'comma_cases':len(commas),'startup_order':orders}))
