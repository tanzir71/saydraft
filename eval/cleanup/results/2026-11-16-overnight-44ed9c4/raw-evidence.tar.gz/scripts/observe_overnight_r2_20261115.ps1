$ErrorActionPreference = 'Stop'
$qaRoot = 'D:\Saydraft-Codex-QA-20261112-01a1cbc7'
$queueRoot = Join-Path $qaRoot 'overnight-44ed9c4-20261115-r2'
$verificationRoot = Join-Path $qaRoot 'overnight-44ed9c4-20261115-r2-verification-r1'
$repoRoot = 'C:\Users\tanzir\Desktop\voice_tray'
$snapshotRoot = Join-Path $qaRoot 'worktrees\microphone-repair-20261115'
$pythonPath = Join-Path $qaRoot 'microphone-repair-package-20261115-r2\venv\Scripts\python.exe'
$sourceCommit = '44ed9c458a78e84e55751b827ed71b96114632ae'
if (Test-Path -LiteralPath $verificationRoot) { throw 'Fresh verification directory required' }
$queueState = Get-Content -LiteralPath (Join-Path $queueRoot 'status.json') -Raw | ConvertFrom-Json
if ($queueState.source -ne $sourceCommit -or $queueState.status -ne 'running') { throw 'Expected live pinned queue' }
$controllerId = [int]$queueState.controller_pid
$cim = Get-CimInstance Win32_Process -Filter "ProcessId=$controllerId"
if ($null -eq $cim -or -not $cim.CommandLine.Contains('run_overnight_queue_20261115.py') -or
    -not $cim.CommandLine.Contains('overnight-44ed9c4-20261115-r2')) { throw 'Controller identity differs' }
$controller = [Diagnostics.Process]::GetProcessById($controllerId)
$heldHandle = $controller.Handle  # Retain this process identity across exit and PID reuse.
if ($controller.StartTime.ToUniversalTime().ToString('o') -ne $cim.CreationDate.ToUniversalTime().ToString('o')) {
    # CIM and .NET may expose different sub-millisecond precision, but must name
    # the same creation within a millisecond while the retained handle is open.
    if ([Math]::Abs(($controller.StartTime.ToUniversalTime() - $cim.CreationDate.ToUniversalTime()).TotalMilliseconds) -gt 1) {
        throw 'Controller creation time differs'
    }
}
New-Item -ItemType Directory -Path $verificationRoot | Out-Null
$record = [ordered]@{source=$sourceCommit;observer_pid=$PID;controller_pid=$controllerId;
    controller_creation_utc=$controller.StartTime.ToUniversalTime().ToString('o');
    status='waiting_for_actual_controller_exit';started_utc=[DateTime]::UtcNow.ToString('o');outcomes=@()}
$record.script_sha256 = [ordered]@{}
foreach ($name in @('observe_overnight_r2_20261115.ps1','verify_overnight_full_latency_20261115.py','verify_overnight_cleanup_20261115.py')) {
    $record.script_sha256[$name] = (Get-FileHash -LiteralPath (Join-Path $qaRoot $name) -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Save-State {
    $pending = Join-Path $verificationRoot 'status.pending.json'
    $record | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $pending -Encoding utf8
    Move-Item -LiteralPath $pending -Destination (Join-Path $verificationRoot 'status.json') -Force
}
Save-State
try {
    $controller.WaitForExit()
    $record.controller_exit_code = $controller.ExitCode
    $record.controller_exit_observed = $controller.HasExited
    $record.controller_exit_observed_utc = [DateTime]::UtcNow.ToString('o')
    $controller.Dispose()
    $queueState = Get-Content -LiteralPath (Join-Path $queueRoot 'status.json') -Raw | ConvertFrom-Json
    if ($queueState.status -in @('starting','running') -or -not $queueState.ended_utc -or
        $queueState.source -ne $sourceCommit -or $queueState.controller_pid -ne $controllerId) {
        throw 'Controller exited without a matching terminal queue receipt'
    }
    if (@($queueState.outcomes | Where-Object { -not $_.tree_exit_observed }).Count -gt 0) {
        throw 'An owned stage tree lacks an observed exit'
    }
    if ($queueState.status -eq 'controller_error' -and -not $queueState.aborted_tree_exit_observed) {
        throw 'Controller error lacks an aborted-tree exit receipt'
    }
    $record.queue_status = $queueState.status
    foreach ($name in $record.script_sha256.Keys) {
        if ((Get-FileHash -LiteralPath (Join-Path $qaRoot $name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.script_sha256[$name]) {
            throw 'Verification source changed while waiting; retain this attempt'
        }
    }
    $record.status = 'verifying_recorded_results'
    Save-State

    function Run-Verification([string]$name, [string[]]$arguments) {
        $start = [Diagnostics.ProcessStartInfo]::new()
        $start.FileName = $pythonPath
        $start.WorkingDirectory = $snapshotRoot
        $start.UseShellExecute = $false
        $start.CreateNoWindow = $true
        $start.RedirectStandardOutput = $true
        $start.RedirectStandardError = $true
        $start.Environment.Clear()
        foreach ($key in @('SYSTEMROOT','WINDIR','COMSPEC','PATH','PATHEXT','PROCESSOR_ARCHITECTURE','NUMBER_OF_PROCESSORS')) {
            $value = [Environment]::GetEnvironmentVariable($key)
            if ($null -ne $value) { $start.Environment[$key] = $value }
        }
        $start.Environment['USERPROFILE'] = Join-Path $queueRoot 'profile\home'
        $start.Environment['LOCALAPPDATA'] = Join-Path $queueRoot 'profile\local'
        $start.Environment['APPDATA'] = Join-Path $queueRoot 'profile\roaming'
        $start.Environment['TEMP'] = Join-Path $queueRoot 'profile\temp'
        $start.Environment['TMP'] = Join-Path $queueRoot 'profile\temp'
        foreach ($key in @('HF_HUB_OFFLINE','HF_HUB_DISABLE_TELEMETRY','DO_NOT_TRACK','PYTHONNOUSERSITE','PYTHONDONTWRITEBYTECODE','PYTHONUTF8')) {
            $start.Environment[$key] = '1'
        }
        $start.Environment['PYTHONIOENCODING'] = 'utf-8'
        foreach ($argument in @('-B','-I') + $arguments) { $start.ArgumentList.Add($argument) }
        $child = [Diagnostics.Process]::Start($start)
        $stdout = $child.StandardOutput.ReadToEndAsync()
        $stderr = $child.StandardError.ReadToEndAsync()
        $child.WaitForExit()
        [IO.File]::WriteAllText((Join-Path $verificationRoot ($name + '.stdout.log')), $stdout.GetAwaiter().GetResult())
        [IO.File]::WriteAllText((Join-Path $verificationRoot ($name + '.stderr.log')), $stderr.GetAwaiter().GetResult())
        $record.outcomes += [ordered]@{name=$name;pid=$child.Id;exit_code=$child.ExitCode;
            exit_observed=$child.HasExited;observed_utc=[DateTime]::UtcNow.ToString('o');arguments=$arguments}
        $child.Dispose()
        Save-State
    }

    $latencyScript = Join-Path $qaRoot 'verify_overnight_full_latency_20261115.py'
    $cleanupScript = Join-Path $qaRoot 'verify_overnight_cleanup_20261115.py'
    # A small completed native debug receipt checks verifier mechanics first.
    Run-Verification 'cleanup-debug-probe' @($cleanupScript,'--run',
        (Join-Path $qaRoot 'overnight-cleanup-probe-cpu-44ed9c4-20261115-r1'),
        '--snapshot',$snapshotRoot,'--repo',$repoRoot,'--debug-probe','--original-inputs',
        '--output',(Join-Path $verificationRoot 'cleanup-debug-probe.json'))
    if ($record.outcomes[-1].exit_code -ne 0) { throw 'Cleanup verifier debug probe failed; preserve and review before full replay' }
    foreach ($stage in $queueState.stages) {
        $output = [string]$stage.output
        if (-not (Test-Path -LiteralPath (Join-Path $output 'report.json'))) {
            $record.outcomes += [ordered]@{name=$stage.name;unavailable=$true;reason='No terminal report';exit_code=$null}
            Save-State
            continue
        }
        if ($stage.kind -eq 'latency') {
            Run-Verification $stage.name @($latencyScript,'--run',$output,'--snapshot',$snapshotRoot,
                '--repo',$repoRoot,'--original-inputs','--input-root',$qaRoot,
                '--output',(Join-Path $verificationRoot ($stage.name + '.json')))
        } else {
            Run-Verification $stage.name @($cleanupScript,'--run',$output,'--snapshot',$snapshotRoot,
                '--repo',$repoRoot,'--queue',$queueRoot,'--original-inputs',
                '--output',(Join-Path $verificationRoot ($stage.name + '.json')))
        }
    }
    $failures = @($record.outcomes | Where-Object { $_.unavailable -or $null -eq $_.exit_code -or $_.exit_code -ne 0 })
    $record.status = if ($failures.Count) { 'complete_with_verification_failures' } else { 'complete' }
} catch {
    $record.status = 'observer_error'
    $record.error = $_.Exception.Message
    throw
} finally {
    $record.ended_utc = [DateTime]::UtcNow.ToString('o')
    Save-State
}
