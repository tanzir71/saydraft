from pathlib import Path
import hashlib
import io
import json
import tarfile
import xml.etree.ElementTree as ET

repo = Path('C:/Users/tanzir/Desktop/voice_tray')
qa = Path(__file__).parent
dest = repo / 'eval/ui/results/2026-11-17-voice-notes'
dest.mkdir(parents=True, exist_ok=True)
names = ['run_worker_tests.py', 'run_ui_tests.py', 'test_notes_render.py', 'archive_notes.py',
         'notes-idle-themed.png', 'notes-recording-themed.png']
runs = ['voice-notes-r1', 'voice-notes-r2', 'voice-notes-r3', 'voice-native-r1',
        'voice-native-r2', 'voice-ui-r1', 'voice-ui-r2', 'voice-ui-r3', 'voice-ui-r4',
        'notes-render-r1', 'notes-render-r2', 'qualification-tests-r1']
for run in runs:
    names += [p.name for p in qa.glob(run + '.*') if p.is_file()]
successful = ['voice-notes-r3', 'voice-native-r1', 'voice-native-r2', 'voice-ui-r4',
              'notes-render-r2', 'qualification-tests-r1']
unique = set()
for run in successful:
    xml = ET.parse(qa / (run + '.xml'))
    for case in xml.findall('.//testcase'):
        assert case.find('failure') is None and case.find('error') is None
        unique.add((case.get('classname'), case.get('name')))
    receipt = json.loads((qa / (run + '.guard.json')).read_bytes())
    assert not receipt['blocked_attempts']
    for key in ('real_audio_sdk_imported', 'owner_profile_used', 'owner_clipboard_used',
                'owner_native_input_used', 'device_enumeration', 'microphone_used'):
        assert receipt[key] is False
sources = ['saydraft/app.py', 'saydraft/core/worker.py', 'saydraft/core/container.py',
           'saydraft/ui/notes_page.py', 'saydraft/ui/notes_presentation.py',
           'saydraft/ui/grouped_settings.py', 'saydraft/ui/bar_motion.py',
           'tests/test_voice_notes.py', 'tests/test_voice_notes_ui.py']
records = []
archive = dest / 'receipts.tar.gz'
with tarfile.open(archive, 'w:gz') as output:
    for name in sorted(set(names)):
        raw = (qa / name).read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        output.addfile(info, io.BytesIO(raw))
        records.append(dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
manifest = dict(schema=1, archive=archive.name, archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                unique_successful_cases=len(unique), successful_runs=successful, records=records,
                source_sha256={p:hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in sources})
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(unique_successful_cases=len(unique), records=len(records), archive_bytes=archive.stat().st_size)))
