import sys,ctypes,json,os
from pathlib import Path
sys.path.insert(0,'C:/Users/tanzir/Desktop/voice_tray')
from tools.public_file_guard import install
q=Path(__file__).resolve().parent;install(q/'cpu-environment.guard.json')
k=ctypes.WinDLL('kernel32.dll',use_last_error=True,winmode=0x800)
class Power(ctypes.Structure):
 _fields_=[('ac',ctypes.c_ubyte),('flags',ctypes.c_ubyte),('percent',ctypes.c_ubyte),('saving',ctypes.c_ubyte),('life',ctypes.c_uint32),('full',ctypes.c_uint32)]
p=Power();k.GetSystemPowerStatus.argtypes=[ctypes.POINTER(Power)];k.GetSystemPowerStatus.restype=ctypes.c_int
power_ok=bool(k.GetSystemPowerStatus(ctypes.byref(p)))
k.GetCurrentProcess.restype=ctypes.c_void_p
k.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)];k.GetProcessAffinityMask.restype=ctypes.c_int
process_mask,system_mask=ctypes.c_size_t(),ctypes.c_size_t()
affinity_ok=bool(k.GetProcessAffinityMask(k.GetCurrentProcess(),ctypes.byref(process_mask),ctypes.byref(system_mask)))
print(json.dumps({'power_status_read':power_ok,'ac_power':p.ac if power_ok else None,'energy_saver':p.saving if power_ok else None,'own_affinity_read':affinity_ok,'own_available_logical_cpus':process_mask.value.bit_count() if affinity_ok else None,'os_process_cpu_count':os.process_cpu_count()}))
