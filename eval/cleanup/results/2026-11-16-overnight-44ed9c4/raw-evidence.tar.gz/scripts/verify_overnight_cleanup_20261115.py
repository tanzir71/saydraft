"""Verify recorded cleanup results after the queue exits; never run inference."""
import argparse
from collections import Counter
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import statistics
import subprocess
import sys

SOURCE = '44ed9c458a78e84e55751b827ed71b96114632ae'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run', type=Path, required=True)
parser.add_argument('--snapshot', type=Path, required=True)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--queue', type=Path)
parser.add_argument('--debug-probe', action='store_true')
parser.add_argument('--original-inputs', action='store_true')
args = parser.parse_args()
root, snapshot = args.run.resolve(), args.snapshot.resolve()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def text_digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def member(base, name):
    relative = PurePosixPath(name)
    assert relative.as_posix() == name and not relative.is_absolute()
    assert '..' not in relative.parts and '\\' not in name and ':' not in name
    path = base.joinpath(*relative.parts)
    assert not path.is_symlink() and path.resolve().is_relative_to(base.resolve())
    return path


report = read(root / 'report.json')
request = read(root.with_suffix('.request.json'))
assert request['repo'] == str(snapshot) and request['output'] == str(root)
assert request['debug'] is args.debug_probe
assert report['git_commit'] == SOURCE and report['source_dirty'] is False
assert report['isolation_declared'] is True and report['full_corpus'] is (not args.debug_probe)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=snapshot, text=True).strip() == SOURCE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=snapshot, text=True).strip()
outcome = None
if not args.debug_probe:
    assert args.queue, 'Full verification requires a terminal queue receipt'
    state = read(args.queue / 'status.json')
    assert state['status'] not in ['starting', 'running'] and state.get('ended_utc')
    outcome = read(root.with_suffix('.queue-exit.json'))
    assert outcome in state['outcomes'] and outcome['tree_exit_observed'] is True
    assert outcome['report_sha256'] == digest(root / 'report.json')
    assert outcome['log_sha256'] == digest(args.queue / (outcome['stage'] + '.log'))

# Bind every measured source object to Git and the immutable checkout. Only a
# Git-attribute-authorized Windows newline conversion is permitted.
fingerprints = report['source_fingerprints']
names = list(fingerprints)
batch = io.BytesIO(subprocess.check_output(['git', 'cat-file', '--batch'], cwd=args.repo,
    input=('\n'.join(SOURCE + ':' + name for name in names) + '\n').encode()))
converted = []
for name in names:
    assert digest(member(snapshot, name)) == fingerprints[name], name
    header = batch.readline().split()
    assert len(header) == 3 and header[1] == b'blob'
    data = batch.read(int(header[2]))
    assert batch.read(1) == b'\n'
    if hashlib.sha256(data).hexdigest() != fingerprints[name]:
        assert b'\r' not in data and b'\0' not in data
        assert hashlib.sha256(data.replace(b'\n', b'\r\n')).hexdigest() == fingerprints[name], name
        converted.append(name)
if converted:
    raw = subprocess.check_output(['git', 'check-attr', '--source=' + SOURCE, '-z', '--stdin', 'text', 'eol'],
        cwd=args.repo, input=('\0'.join(converted) + '\0').encode()).split(b'\0')
    attrs = {(raw[i].decode(), raw[i + 1]): raw[i + 2] for i in range(0, len(raw) - 1, 3)}
    assert all(attrs[name, b'text'] in [b'auto', b'set'] and attrs[name, b'eol'] in
        [b'unspecified', b'crlf'] for name in converted)

gpu = request['tier'] == 'pro'
guard = read(root.with_suffix('.guard.json'))
worker = read(root.with_suffix('.guard.worker.json'))
assert request['pid'] == guard['pid'] == worker['pid']
assert guard['blocked_attempts'] == worker['port_attempts'] == []
assert all(guard[key] is False for key in ['real_audio_sdk_imported', 'owner_profile_used',
    'owner_clipboard_used', 'owner_native_input_used', 'device_enumeration', 'microphone_used'])
assert guard['gpu_metadata_allowed'] is gpu
assert worker['kind'] == 'public-file-worker-with-refusing-foreground-port'
assert worker['production_context_adapter_loaded'] is False
for row in guard['gpu_metadata_dlls']:
    assert gpu and row == {'caller': 'saydraft.models.windows_hardware', 'dll': 'vulkan-1.dll', 'system32_only': True}

# Guarded pure rules replay: explicit in-memory delivery, no model or host ports.
sys.path.insert(0, str(snapshot))
from tools.public_worker_guard import install
install(args.output.with_suffix('.guard.json'))
from saydraft.cleanup.llm.candidates import get_candidate, candidate_directory, candidate_ready
from saydraft.cleanup.llm.eval_validation import load_cases
from saydraft.cleanup.llm.bakeoff import corpus_digest
from saydraft.cleanup.llm.validate import validate_llm_output
from saydraft.dictation import DictationConfig, DictationPipeline
from saydraft.dictation.glossary import Glossary
from saydraft.dictation.llm_local import LocalLLMConfig
from saydraft.eval import EvalCase, execute_case, load_eval_corpus
from saydraft.models.runtime_ids import runtime_model_id

golden = load_eval_corpus(snapshot / 'tests/eval_corpus.jsonl')
adversarial = load_cases(snapshot / 'tests/cleanup_adversarial.jsonl')
assert len(golden) == 556 and len(adversarial) == 100
if args.debug_probe:
    golden, adversarial = golden[:1], adversarial[:1]
assert report['golden_sha256'] == corpus_digest(golden)
assert report['adversarial_sha256'] == text_digest(json.dumps(adversarial, sort_keys=True))
identifier = 'qwen35-2b-q4-k-m' if gpu else 'qwen35-08b-q4-k-m'
backend = 'vulkan' if gpu else 'cpu'
assert report['candidate'] == get_candidate(identifier)
assert report['runtime'] == runtime_model_id(backend)
assert report['backend'] == backend and report['device_override'] == ('Vulkan1' if gpu else None)
assert report['context_size'] == 4096 and report['max_output_tokens'] == 256
assert report['decoding_temperature'] == 0 and report['threads'] == 4
policy = request['mode'] == 'policy'
assert report['quality_timeout_ms'] == (800 if policy else 120000)
assert report['interactive_budget_gate'] is policy and report['interactive_prompt_preparation'] is policy
for name, value in report['prompt_sha256'].items():
    assert digest(member(snapshot / 'saydraft/cleanup/llm/prompts', name)) == value

rows = [json.loads(line) for line in (root / 'cases.jsonl').read_text(encoding='utf-8').splitlines()]
fixtures = [('golden', case, ()) for case in golden] + [('adversarial',
    EvalCase(row['id'], row['input'], '', row.get('mode', 'balanced'), 'general'),
    tuple(row.get('glossary', ()))) for row in adversarial]
assert len(rows) <= len(fixtures)
baseline = DictationPipeline(DictationConfig(glossary_path='', llm=LocalLLMConfig(enabled=False)))
try:
    for row, (suite, case, terms) in zip(rows, fixtures):
        assert row['suite'] == suite and row['id'] == case.id
        assert row['input'] == case.input_text
        assert row['expected'] == (case.expected if suite == 'golden' else None)
        for key, field in [('input', 'input_sha256'), ('actual', 'output_sha256'), ('rules', 'baseline_sha256')]:
            assert text_digest(row[key]) == row[field]
        baseline.glossary = Glossary(protected_terms=terms)
        rules = execute_case(case, baseline)
        assert rules.cleaned_text == row['rules']
        action_same = row['enter_sent'] == rules.insertion.enter_sent
        same = row['actual'] == rules.cleaned_text
        bypass = case.mode == 'raw' or case.profile == 'code/comments' or case.app_group == 'code'
        preserved = action_same and (same if bypass else same or validate_llm_output(
            rules.cleaned_text, row['actual'], mode=case.mode, intensity=case.intensity,
            glossary=terms, language=case.language).ok)
        exact = row['actual'] == case.expected and row['enter_sent'] == case.expected_enter
        rules_exact = rules.cleaned_text == case.expected and rules.insertion.enter_sent == case.expected_enter
        assert row['same_as_rules'] is same and row['preservation_ok'] is preserved
        assert row['exact_pass'] is (exact if suite == 'golden' else None)
        assert row['rules_exact_pass'] is (rules_exact if suite == 'golden' else None)
        assert type(row['seconds']) in [int, float] and math.isfinite(row['seconds']) and row['seconds'] >= 0
        if row['decision'] == 'accepted':
            assert any(call['returned_candidate'] and call.get('client_reason') == 'ok'
                and call.get('source_tokens', 0) > 0 for call in row['calls'])
finally:
    baseline.close()

groups = {}
for suite, requested in [('golden', len(golden)), ('adversarial', len(adversarial))]:
    selected = [row for row in rows if row['suite'] == suite]
    calls = [call for row in selected for call in row['calls']]
    summary = dict(requested=requested, completed=len(selected), cleanup_calls=len(calls),
        returned_candidates=sum(call['returned_candidate'] for call in calls),
        client_replies=sum('client_reason' in call for call in calls),
        client_replies_with_token_counts=sum(call.get('source_tokens', 0) > 0 for call in calls),
        accepted_replies=sum(row['decision'] == 'accepted' for row in selected),
        decisions=dict(Counter(row['decision'] for row in selected)),
        call_reasons=dict(Counter(call['reason'] for call in calls)),
        preservation_failures=[row['id'] for row in selected if not row['preservation_ok']])
    if suite == 'golden':
        summary.update(exact_passes=sum(row['exact_pass'] for row in selected),
            regressions=[row['id'] for row in selected if row['rules_exact_pass'] and not row['exact_pass']])
    assert all(report['suites'][suite][key] == value for key, value in summary.items())
    groups[suite] = summary

models = {}
if args.original_inputs:
    argv = request['argv']
    candidate = get_candidate(identifier)
    directory = candidate_directory(Path(argv[argv.index('--models-dir') + 1]), candidate)
    assert candidate_ready(candidate, directory)
    models[identifier] = str(directory)
    runtime = Path(argv[argv.index('--runtime-dir') + 1])
    manifest = read(snapshot / 'saydraft/models/manifest.json')
    record = next(model for model in manifest['models'] if model['id'] == report['runtime'])
    for entry in record['files']:
        path = member(runtime, entry['path'])
        assert path.stat().st_size == entry['size'] and digest(path) == entry['sha256']
    models[report['runtime']] = str(runtime)

calibration = report.get('live_decoder_calibration') or {}
rates = calibration.get('tokens_per_second', []) if policy else [
    sample['tokens_per_second'] for sample in report.get('throughput_60_tokens', []) if sample['valid']]
rates_valid = len(rates) == 3 and all(type(rate) in [int, float] and math.isfinite(rate) and rate > 0 for rate in rates)
target = 40 if gpu else 25
complete = len(rows) == len(fixtures) and not report.get('error_type') and all(report.get('native_exit_observed', []))
complete = bool(complete and report.get('native_exit_observed') and rates_valid)
if not args.debug_probe:
    complete = complete and outcome['exit_code'] == 0 and not outcome['timed_out']
quality = (complete and groups['golden']['exact_passes'] >= .92 * len(golden)
    and not groups['golden']['regressions'] and not groups['golden']['preservation_failures']
    and not groups['adversarial']['preservation_failures'])
result = dict(source=SOURCE, run=str(root), integrity_passed=True, debug_probe=args.debug_probe,
    report_sha256=digest(root / 'report.json'), journal_sha256=digest(root / 'cases.jsonl'),
    source_objects_verified=len(names), baseline_rows_replayed=len(rows), suites=groups,
    original_inputs_verified=args.original_inputs, models=models, measurement_complete=complete,
    native_exit_observed=report.get('native_exit_observed'), policy=policy,
    quality_threshold_and_regression_gates_met=quality,
    accepted_model_reply_present=groups['golden']['accepted_replies'] > 0,
    all_adversarial_cases_have_token_counts=groups['adversarial']['client_replies_with_token_counts'] == len(adversarial),
    decoder_rates=rates, decoder_median_tps=statistics.median(rates) if rates_valid else None,
    decoder_target_tps=target, decoder_target_met=rates_valid and statistics.median(rates) >= target,
    owner_accuracy_accepted=False, native_windows_acceptance=False, model_promotion=False)
with args.output.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['suites', 'models']}))
